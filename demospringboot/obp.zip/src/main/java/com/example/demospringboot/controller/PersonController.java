package com.example.demospringboot.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demospringboot.entity.Buyer;
import com.example.demospringboot.entity.Person;
import com.example.demospringboot.entity.Seller;
import com.example.demospringboot.service.BuyerService;
import com.example.demospringboot.service.PersonService;
import com.example.demospringboot.service.SellerService;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class PersonController {

    private final PersonService personService;
    private final BuyerService buyerService;
    private final SellerService sellerService;

    public PersonController(PersonService personService, BuyerService buyerService, SellerService sellerService) {
        this.personService = personService;
        this.buyerService = buyerService;
        this.sellerService = sellerService;
    }

    // ================= PERSON =================

    @GetMapping(value = {"/person", "/person/"})
    public String personPage(Model model) {
        model.addAttribute("personList", personService.getAllPerson());
        model.addAttribute("personInfo", new Person());
        return "person.html";
    }

    @GetMapping("/person/{id}")
    public String personGetRec(Model model, @PathVariable("id") long id) {
        model.addAttribute("personList", personService.getAllPerson());
        model.addAttribute("personRec", personService.getPersonById(id));
        return "person.html";
    }

    @PostMapping(value = {"/person/submit/", "/person/submit/{id}"}, params = {"add"})
    public String personAdd(@ModelAttribute("personInfo") Person personInfo) {
        personService.addPerson(personInfo);
        return "redirect:/person";
    }

    @PostMapping(value = "/person/submit/{id}", params = {"edit"})
    public String personEdit(@ModelAttribute("personInfo") Person personInfo, @PathVariable("id") long id) {
        personService.updatePerson(id, personInfo);
        return "redirect:/person";
    }

    @PostMapping(value = "/person/submit/{id}", params = {"delete"})
    public String personDelete(@PathVariable("id") long id) {
        personService.deletePerson(id);
        return "redirect:/person";
    }

    // ================= BUYER =================

    @GetMapping(value = {"/buyer", "/buyer/"})
    public String buyerPage(Model model, HttpServletRequest request) {

        // kalau belum login seller → redirect login
        if (request.getSession().getAttribute("Seller") == null) {
            request.getSession().setAttribute("pageBuyer", "B");
            return "redirect:/login";
        }

        model.addAttribute("buyerList", buyerService.getAllBuyers());
        model.addAttribute("buyerInfo", new Buyer());
        model.addAttribute("logSeller", request.getSession().getAttribute("Seller"));
        return "buyer.html";
    }

    @GetMapping("/buyer/{id}")
    public String buyerGetRec(Model model, @PathVariable("id") long id, HttpServletRequest request) {
        model.addAttribute("buyerList", buyerService.getAllBuyers());
        model.addAttribute("buyerRec", buyerService.getBuyerById(id));
        model.addAttribute("logSeller", request.getSession().getAttribute("Seller"));
        return "buyer.html";
    }

    @PostMapping(value = {"/buyer/submit/", "/buyer/submit/{id}"}, params = {"add"})
    public String buyerAdd(@ModelAttribute("buyerInfo") Buyer buyerInfo) {
        buyerService.addBuyer(buyerInfo);
        return "redirect:/buyer";
    }

    @PostMapping(value = "/buyer/submit/{id}", params = {"edit"})
    public String buyerEdit(@ModelAttribute("buyerInfo") Buyer buyerInfo, @PathVariable("id") long id) {
        buyerService.updateBuyer(id, buyerInfo);
        return "redirect:/buyer";
    }

    @PostMapping(value = "/buyer/submit/{id}", params = {"delete"})
    public String buyerDelete(@PathVariable("id") long id) {
        buyerService.deleteBuyer(id);
        return "redirect:/buyer";
    }

    // ================= SELLER =================

    @GetMapping(value = {"/seller", "/seller/"})
    public String sellerPage(Model model, HttpServletRequest request) {
        Seller loggedSeller = (Seller) request.getSession().getAttribute("Seller");

        if (loggedSeller == null)
            return "redirect:/login";

        model.addAttribute("sellerList", sellerService.getAllSeller());
        model.addAttribute("sellerInfo", new Seller());
        model.addAttribute("logSeller", loggedSeller);
        return "seller.html";
    }

    @GetMapping("/seller/{id}")
    public String sellerGetRec(Model model, @PathVariable("id") long id, HttpServletRequest request) {
        model.addAttribute("sellerList", sellerService.getAllSeller());
        model.addAttribute("sellerRec", sellerService.getSellerById(id));
        model.addAttribute("logSeller", request.getSession().getAttribute("Seller"));
        return "seller.html";
    }

    @PostMapping(value = {"/seller/submit/", "/seller/submit/{id}"}, params = {"add"})
    public String sellerAdd(@ModelAttribute("sellerInfo") Seller sellerInfo) {
        sellerService.addSeller(sellerInfo);
        return "redirect:/seller";
    }

    @PostMapping(value = "/seller/submit/{id}", params = {"edit"})
    public String sellerEdit(@ModelAttribute("sellerInfo") Seller sellerInfo, @PathVariable("id") long id) {
        sellerService.updateSeller(id, sellerInfo);
        return "redirect:/seller";
    }

    @PostMapping(value = "/seller/submit/{id}", params = {"delete"})
    public String sellerDelete(@PathVariable("id") long id) {
        sellerService.deleteSeller(id);
        return "redirect:/seller";
    }

    // ================= LOGIN =================

    @GetMapping(value = "/login")
    public String sellerLoginPage(HttpServletRequest request) {

        // kalau sudah login → kembali ke seller
        if (request.getSession().getAttribute("Seller") != null)
            return "redirect:/seller";

        return "login.html";
    }

    @PostMapping(value = "/validateLogin")
    public String sellerLogin(Model model,
                              @RequestParam("kode") String kodeUser,
                              @RequestParam("password") String passUser,
                              HttpServletRequest request) {

        Seller S = sellerService.findSeller(kodeUser);

        if (S != null && passUser.equals(S.getPassword())) {
            request.getSession().setAttribute("Seller", S);

            // cek kalau sebelumnya mau ke buyer
            if (request.getSession().getAttribute("pageBuyer") != null) {
                request.getSession().removeAttribute("pageBuyer");
                return "redirect:/buyer";
            }

            return "redirect:/seller";
        }

        model.addAttribute("error", "Kode atau Password salah!");
        return "login.html";
    }

    @GetMapping(value = "/sellerlogout")
    public String sellerLogout(HttpServletRequest request) {
        request.getSession().invalidate();
        return "redirect:/login";
    }
}
