package com.example.demospringboot.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public class Produk {
    @Id 
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull@Size(min = 3, max = 50)
    private String tipe;

    @Size(min = 4, max = 12)
    private String produsen;

    private Integer ram;

    //Constructor
    public Produk() {}

    public Produk(String tipe, String produsen, Integer ram){
        this.tipe = tipe;
        this.produsen = produsen;
        this.ram = ram;
    }

    //getters and setters
    public void setId(Long id) {
        this.id = id;
    }
    public Long getId() {
        return id;
    }
    public void setTipe(String tipe) {
        this.tipe = tipe;
    }
    public String getTipe() {
        return tipe;
    }
    public void setProdusen(String produsen) {
        this.produsen = produsen;
    }
    public String getProdusen() {
        return produsen;
    }
    public void setRam(Integer ram) {
        this.ram = ram;
    }
    public Integer getRam() {
        return ram;
    }
}