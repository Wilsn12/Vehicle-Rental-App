package com.example.demospringboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demospringboot.entity.Rental;
import com.example.demospringboot.repository.RentalRepository;

@Service
public class RentalService {

    @Autowired
    private RentalRepository rentalRepository;

    public List<Rental> getAllRental() {
        return rentalRepository.findAll();
    }

    public Rental addRental(Rental obj) {
        return rentalRepository.save(obj);
    }

    public Rental getRentalById(String id) {
        return rentalRepository.findById(id).orElse(null);
    }

    public Rental updateRental(String id, Rental obj) {

        return rentalRepository.save(obj);
    }

    public void deleteRental(String id) {
        rentalRepository.deleteById(id);
    }
}
