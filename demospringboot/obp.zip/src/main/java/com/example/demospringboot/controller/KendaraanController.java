// package com.example.demospringboot.controller;

// import org.springframework.stereotype.Controller;
// import org.springframework.web.bind.annotation.RequestParam;
// import org.springframework.web.bind.annotation.GetMapping;
// import org.springframework.ui.Model;
// import org.springframework.web.bind.annotation.PathVariable;
// import org.springframework.web.bind.annotation.ModelAttribute;
// import org.springframework.web.bind.annotation.PostMapping;

// import com.example.demospringboot.entity.Kendaraan;
// import com.example.demospringboot.entity.Mobil;
// import com.example.demospringboot.entity.Motor;
// import com.example.demospringboot.entity.Bus;
// import com.example.demospringboot.service.MobilService;
// import com.example.demospringboot.service.MotorService;
// import com.example.demospringboot.service.BusService;
// import com.example.demospringboot.service.KendaraanService;

// import jakarta.servlet.http.HttpServletRequest;

// @Controller
// public class KendaraanController {
//     private final KendaraanService kendaraanService;
//     private final MobilService mobilService;
//     private final MotorService motorService;
//     private final BusService busService;

//     public KendaraanController(KendaraanService kendaraanService, MobilService mobilService, MotorService motorService, BusService busService) {
//         this.kendaraanService = kendaraanService;
//         this.mobilService = mobilService;
//         this.motorService = motorService;
//         this.busService = busService;
//     }

//     @GetMapping("/kendaraan", "/kendaraan/")
//     public String kendaraanPage(Model model) {
//         model.addAttribute("kendaraanList", kendaraanService.getAllKendaraan());
//         model.addAttribute("kendaraanInfo", new Kendaraan());
//         return "kendaraan.html";
//     }

//     @GetMapping("/kendaraan/{id}")
//     public String kendaraanGetRec(Model model, @PathVariable("id") long id) {
//         model.addAttribute("kendaraanList", kendaraanService.getAllKendaraan());
//         model.addAttribute("kendaraanRec", kendaraanService.getKendaraanById(id));
//         return "kendaraan.html";
//     }

//     @PostMapping(value = "/kendaraan/submit/", "/kendaraan/submit/{id}", params = {"add"})
//     public String kendaraanAdd(@ModelAttribute("kendaraanInfo") Kendaraan kendaraanInfo) {
//         kendaraanService.addKendaraan(kendaraanInfo);
//         return "redirect:/kendaraan";
//     }
    
//     @PostMapping(value = "/kendaraan/submit/{id}", params = {"edit"})
//     public String kendaraanEdit(@ModelAttribute("kendaraanInfo") Kendaraan kendaraanInfo, @PathVariable("id") long id){
//         kendaraanService.updateKendaraan(id, kendaraanInfo);
//         return "redirect:/kendaraan";
//     }

//     @PostMapping(value = "/kendaraan/submit/{id}", params = {"delete"})
//     public String kendaraanDelete(@PathVariable("id") long id) {
//         kendaraanService.deleteKendaraan(id);
//         return "redirect:/kendaraan";   
//     }

//     //Motor

//     @GetMapping("/motor", "/motor/")
//     public String motorPage(Model model) {
//         model.addAttribute("motorList", motorService.getAllMotor());
//         model.addAttribute("motorInfo", new Motor());
//         return "motor.html";
//     }

//     @GetMapping("/motor/{id}")
//     public String motorGetRec(Model model, @PathVariable("id") long id) {
//         model.addAttribute("motorList", motorService.getAllMotor());
//         model.addAttribute("motorRec", motorService.getMotorById(id));
//         return "motor.html";
//     }

//     @PostMapping(value = "/motor/submit/", "/motor/submit/{id}", params = {"add"})
//     public String motorAdd(@ModelAttribute("motorInfo") Motor motorInfo) {
//         motorService.addMotor(motorInfo);
//         return "redirect:/motor";
//     }

//     @PostMapping(value = "/motor/submit/{id}", params = {"edit"})
//     public String motorEdit

    
// }
