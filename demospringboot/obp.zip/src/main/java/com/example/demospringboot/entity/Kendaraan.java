package com.example.demospringboot.entity;
import jakarta.persistence.Entity;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Size;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public class Kendaraan {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Size(min = 8, max = 9)
    private String plat;

    private String model;

    private String merk;

    private int tahun;

    private String status;

    private String BBM;

    private String harga;

    private String warna;

    public Kendaraan (String plat, String model, String merk, int tahun, String status, String BBM, String harga, String warna){
        this.plat = plat;
        this.model = model;
        this.merk = merk;
        this.tahun = tahun;
        this.status = status;
        this.BBM = BBM;
        this.harga = harga;
        this.warna = warna;
    }

    public void setStatus(String status){
        this.status = status;
    }

    public void setHarga(double harga){
        this.harga = String.valueOf(harga);
    }

    public void setWarna(String warna){
        this.warna = warna;
    }

    // Getter methods
    public String getPlat(){
        return plat;
    }

    public String getModel(){
        return model;
    }

    public String getMerk(){
        return merk;
    }

    public int getTahun(){
        return tahun;
    }

    public String getStatus(){
        return status;
    }

    public String getBBM(){
        return BBM;
    }

    public String getHarga(){
        return harga;
    }

    public String getWarna(){
        return warna;
    }

//     // Overloading
//     public double hitungBiaya(int lamaSewa, double biayaAdmin) {
//         return (harga * lamaSewa) + biayaAdmin;
//     }
}
