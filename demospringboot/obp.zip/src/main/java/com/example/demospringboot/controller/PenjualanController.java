package com.example.demospringboot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demospringboot.entity.Penjualan;
import com.example.demospringboot.service.BuyerService;
import com.example.demospringboot.service.PenjualanService;
import com.example.demospringboot.service.ProdukService;
import com.example.demospringboot.service.SellerService;

@Controller
public class PenjualanController {

    @Autowired
    private PenjualanService penjualanService;

    @Autowired
    private BuyerService buyerService;

    @Autowired
    private SellerService sellerService;

    @Autowired
    private ProdukService produkService;

    private void loadDropdownData(Model model) {
        model.addAttribute("buyerList", buyerService.getAllBuyers());
        model.addAttribute("sellerList", sellerService.getAllSeller());
        model.addAttribute("produkList", produkService.getAllProduk());
    }

    @GetMapping("/penjualan")
    public String penjualanPage(Model model) {
        model.addAttribute("penjualanList", penjualanService.getAllPenjualan());
        model.addAttribute("penjualanInfo", new Penjualan());
        loadDropdownData(model);
        return "penjualan.html";
    }

    @GetMapping("/penjualan/{id}")
    public String penjualanGetRec(Model model, @PathVariable("id") int id) {
        Penjualan penjualanRec = penjualanService.getPenjualanById(id);

        model.addAttribute("penjualanList", penjualanService.getAllPenjualan());
        model.addAttribute("penjualanRec", penjualanRec);
        loadDropdownData(model);
        return "penjualan.html";
    }

    @PostMapping(value={"/penjualan/submit/", "/penjuan/submit/{id}"}, params={"add"})
    public String penjualanAdd(@ModelAttribute("penjualanInfo") Penjualan penjualanInfo) {
        penjualanService.addPenjualan(penjualanInfo);
        return "redirect:/penjualan";
    }

    @PostMapping(value="/penjualan/submit/{id}", params={"edit"})
    public String penjualanEdit(@ModelAttribute("penjualanInfo") Penjualan penjualanInfo,
                                @PathVariable("id") int id) {
        penjualanService.updatePenjualan(id, penjualanInfo);
        return "redirect:/penjualan";
    }

    @PostMapping(value="/penjualan/submit/{id}", params={"delete"})
    public String penjualanDelete(@PathVariable("id") int id) {
        penjualanService.deletePenjualan(id);
        return "redirect:/penjualan";
    }
}
