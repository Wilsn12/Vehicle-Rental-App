package com.example.demospringboot.entity;

import jakarta.persistence.Entity;

@Entity
public class Tablet extends Produk{
    private byte tipeStylus;
    
    public Tablet(){}

    public Tablet(String t, String p, Integer r, byte tipeStylus){
        super(t, p, r);
        this.tipeStylus = tipeStylus;
    }

    public void setTipeStylus(byte tipeStylus){
        this.tipeStylus = tipeStylus;
    }
    public byte getTipeStylus(){
        return tipeStylus;
    }
}
