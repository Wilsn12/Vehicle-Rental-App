package com.example.demospringboot.entity;

import jakarta.persistence.Entity;

@Entity
public class Petugas extends Orang {

    public Petugas() {
    }

    public Petugas(String kode, String name, String noHP, String username, String password) {
        super(kode, name, noHP, username, password);
    }
}
