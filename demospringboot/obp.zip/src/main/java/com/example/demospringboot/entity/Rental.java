package com.example.demospringboot.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class Rental {

    @Id
    private String RentalID;

    private int LamaSewa;
    private long TotalBiaya;

    @ManyToOne
    private Kendaraan Kendaraan;

    @ManyToOne
    private Petugas Petugas;

    @ManyToOne
    private Penyewa Penyewa;

    public Rental() {}

public Rental(String RentalID, int LamaSewa, long TotalBiaya, 
                  Kendaraan Kendaraan, Petugas Petugas, Penyewa Penyewa) {
        this.RentalID = RentalID;
        this.LamaSewa = LamaSewa;
        this.TotalBiaya = TotalBiaya;
        this.Kendaraan = Kendaraan;
        this.Petugas = Petugas;
        this.Penyewa = Penyewa;
    }


    public void setRentalID(String rentalID) { this.RentalID = rentalID; }
    public String getRentalID() { return RentalID; }

    public void setLamaSewa(int lamaSewa) { this.LamaSewa = lamaSewa; }
    public int getLamaSewa() { return LamaSewa; }

    public void setTotalBiaya(long totalBiaya) { this.TotalBiaya = totalBiaya; }
    public long getTotalBiaya() { return TotalBiaya; }

    public void setKendaraan(Kendaraan Kendaraan) { this.Kendaraan = Kendaraan; }
    public Kendaraan getKendaraan() { return Kendaraan; }

    public void setPenyewa(Penyewa Penyewa) { this.Penyewa = Penyewa; }
    public Penyewa getPenyewa() { return Penyewa; }

    public void setPetugas(Petugas Petugas) { this.Petugas = Petugas; }
    public Petugas getPetugas() { return Petugas; }
}
