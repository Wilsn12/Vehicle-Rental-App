package com.example.demospringboot.entity;

import jakarta.persistence.Entity;

@Entity
public class Penyewa extends Orang {
    private String alamat;
    private String noSIM;

    public Penyewa() {
    }

    public Penyewa(String kode, String name, String noHP, String username, String password, String alamat, String noSIM) {
        super(kode, name, noHP, username, password);
        this.alamat = alamat;
        this.noSIM = noSIM;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }
    public String getAlamat() {
        return alamat;
    }
    public void setNoSIM(String noSIM) {
        this.noSIM = noSIM;
    }
    public String getNoSim() {
        return noSIM;
    }
}
