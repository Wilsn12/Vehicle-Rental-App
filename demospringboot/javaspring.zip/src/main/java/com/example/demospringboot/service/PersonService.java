package com.example.demospringboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demospringboot.entity.Person;
import com.example.demospringboot.repository.PersonRepository;
 
@Service
public class PersonService {
    @Autowired
    private PersonRepository personRepository;
    public List<Person> getAllPerson() {
    return personRepository.findAll();
    }
}

