package com.example.demospringboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping; 

import com.example.demospringboot.entity.Person;
import com.example.demospringboot.service.PersonService;
@Controller
public class PersonController {
    @Autowired
    private PersonService personService;
    @GetMapping("/person")
    public String PersonPage(Model model) {
    @SuppressWarnings("unused")
    List<Person> personList;
    model.addAttribute("personList", personService.getAllPerson());
    return "person.html";
  }
}
