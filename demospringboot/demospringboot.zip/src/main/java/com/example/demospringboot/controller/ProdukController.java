package com.example.demospringboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demospringboot.entity.HandPhone;
import com.example.demospringboot.entity.Laptop;
import com.example.demospringboot.entity.Produk;
import com.example.demospringboot.entity.Tablet;
import com.example.demospringboot.service.HandPhoneService;
import com.example.demospringboot.service.LaptopService;
import com.example.demospringboot.service.ProdukService;
import com.example.demospringboot.service.TabletService;

@Controller
public class ProdukController {

    @Autowired
    private ProdukService produkService;

    @Autowired
    private LaptopService laptopService;

    @Autowired
    private TabletService tabletService;

    @Autowired
    private HandPhoneService handphoneService;

    @GetMapping({"/produk", "/produk/"})
    public String produkPage(Model model) {
        List<Produk> produkList = produkService.getAllProduk();
        model.addAttribute("produkList", produkList);
        model.addAttribute("produkInfo", new Produk());
        return "produk.html";
    }

    @GetMapping("/produk/{id}")
    public String produkGetRec(Model model, @PathVariable("id") Long id) {
        List<Produk> produkList = produkService.getAllProduk();
        Produk produkRec = produkService.getProdukById(id);
        model.addAttribute("produkList", produkList);
        model.addAttribute("produkRec", produkRec);
        return "produk.html";
    }

    @PostMapping("/produk/submit")
    public String produkSubmit(@ModelAttribute("produkInfo") Produk produkInfo) {
        produkService.addProduk(produkInfo);
        return "redirect:/produk";
    }

    @PostMapping("/produk/submit/{id}")
    public String produkSubmitEdit(@ModelAttribute("produkInfo") Produk produkInfo, @PathVariable("id") Long id) {
        produkService.updateProduk(id, produkInfo);
        return "redirect:/produk";
    }

    @GetMapping("/produk/delete/{id}")
    public String produkDelete(@PathVariable("id") Long id) {
        produkService.deleteProduk(id);
        return "redirect:/produk";
    }

    @GetMapping({"/laptop", "/laptop/"})
    public String laptopPage(Model model) {
        List<Laptop> laptopList = laptopService.getAllLaptop();
        model.addAttribute("laptopList", laptopList);
        model.addAttribute("laptopInfo", new Laptop());
        return "laptop.html";
    }

    @GetMapping("/laptop/{id}")
    public String laptopGetRec(Model model, @PathVariable("id") Long id) {
        List<Laptop> laptopList = laptopService.getAllLaptop();
        Laptop laptopRec = laptopService.getLaptopById(id);
        model.addAttribute("laptopList", laptopList);
        model.addAttribute("laptopRec", laptopRec);
        return "laptop.html";
    }

    @PostMapping("/laptop/submit")
    public String laptopSubmit(@ModelAttribute("laptopInfo") Laptop laptopInfo) {
        laptopService.addLaptop(laptopInfo);
        return "redirect:/laptop";
    }

    @PostMapping("/laptop/submit/{id}")
    public String laptopSubmitEdit(@ModelAttribute("laptopInfo") Laptop laptopInfo, @PathVariable("id") Long id) {
        laptopService.updateLaptop(id, laptopInfo);
        return "redirect:/laptop";
    }

    @GetMapping("/laptop/delete/{id}")
    public String laptopDelete(@PathVariable("id") Long id) {
        laptopService.deleteLaptop(id);
        return "redirect:/laptop";
    }

    @GetMapping({"/tablet", "/tablet/"})
    public String tabletPage(Model model) {
        List<Tablet> tabletList = tabletService.getAllTablet();
        model.addAttribute("tabletList", tabletList);
        model.addAttribute("tabletInfo", new Tablet());
        return "tablet.html";
    }

    @GetMapping("/tablet/{id}")
    public String tabletGetRec(Model model, @PathVariable("id") Long id) {
        List<Tablet> tabletList = tabletService.getAllTablet();
        Tablet tabletRec = tabletService.getTabletById(id);
        model.addAttribute("tabletList", tabletList);
        model.addAttribute("tabletRec", tabletRec);
        return "tablet.html";
    }

    @PostMapping("/tablet/submit")
    public String tabletSubmit(@ModelAttribute("tabletInfo") Tablet tabletInfo) {
        tabletService.addTablet(tabletInfo);
        return "redirect:/tablet";
    }

    @PostMapping("/tablet/submit/{id}")
    public String tabletSubmitEdit(@ModelAttribute("tabletInfo") Tablet tabletInfo, @PathVariable("id") Long id) {
        tabletService.updateTablet(id, tabletInfo);
        return "redirect:/tablet";
    }

    @GetMapping("/tablet/delete/{id}")
    public String tabletDelete(@PathVariable("id") Long id) {
        tabletService.deleteTablet(id);
        return "redirect:/tablet";
    }

    @GetMapping({"/handphone", "/handphone/"})
    public String handphonePage(Model model) {
        List<HandPhone> handphoneList = handphoneService.getAllHandPhone();
        model.addAttribute("handphoneList", handphoneList);
        model.addAttribute("handphoneInfo", new HandPhone());
        return "handphone.html";
    }

    @GetMapping("/handphone/{id}")
    public String handphoneGetRec(Model model, @PathVariable("id") Long id) {
        List<HandPhone> handphoneList = handphoneService.getAllHandPhone();
        HandPhone handphoneRec = handphoneService.getHandPhoneById(id);
        model.addAttribute("handphoneList", handphoneList);
        model.addAttribute("handphoneRec", handphoneRec);
        return "handphone.html";
    }

    @PostMapping("/handphone/submit")
    public String handphoneSubmit(@ModelAttribute("handphoneInfo") HandPhone handphoneInfo) {
        handphoneService.addHandPhone(handphoneInfo);
        return "redirect:/handphone";
    }

    @PostMapping("/handphone/submit/{id}")
    public String handphoneSubmitEdit(@ModelAttribute("handphoneInfo") HandPhone handphoneInfo, @PathVariable("id") Long id) {
        handphoneService.updateHandPhone(id, handphoneInfo);
        return "redirect:/handphone";
    }

    @GetMapping("/handphone/delete/{id}")
    public String handphoneDelete(@PathVariable("id") Long id) {
        handphoneService.deleteHandPhone(id);
        return "redirect:/handphone";
    }
}
