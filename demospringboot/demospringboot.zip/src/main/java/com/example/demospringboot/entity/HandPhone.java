package com.example.demospringboot.entity;

import jakarta.persistence.Entity;

@Entity
public class HandPhone extends Produk {
    private String gen;

    public HandPhone() {
    }

    public HandPhone(String t, String p, String w, int r, String g) {
        super(t, p, r);
        this.gen = g;
    }

    public void setGen(String g) {
        this.gen = g;
    }

    public String getGen() {
        return gen;
    }
}
