package com.example.demospringboot.entity;
import java.time.LocalDateTime;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
 public class Penjualan {
 @Id
 @GeneratedValue(strategy = GenerationType.IDENTITY)
 private Long saleID;
 @ManyToOne
 private Buyer buyer;
 private Seller seller;
 @ManyToOne
 private Produk produk;
 private int jumlah;
 @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
 private LocalDateTime tanggal;
 private Long hargaJual;
 public Penjualan(Long id, Buyer buyer, Seller seller, int jumlah, LocalDateTime tanggal, Long harga, Produk produk) {
 this.saleID = id;
 this.buyer = buyer;
this.seller = seller;
 this.jumlah = jumlah;
 this.tanggal = tanggal;
 this.hargaJual = harga;
 this.produk = produk;
 }
 public Penjualan() {}
 public void setSaleID(Long saleID) {
 this.saleID = saleID;
 }
 public Long getSaleID() {
 return saleID;
 }
 public void setBuyer(Buyer buyer) {
    this.buyer = buyer;
    }
public Buyer getBuyer() {
    return buyer;
    }
public void setSeller(Seller seller) {
 this.seller = seller;
    }
    public Seller getSeller() {
    return seller;
    }
 public void setJumlah(int jumlah) {
 this.jumlah = jumlah;
 }
 public int getJumlah() {
 return jumlah;
 }
 public void setTanggal(LocalDateTime tanggal) {
 this.tanggal = tanggal;
 }
 public LocalDateTime getTanggal() {
 return tanggal;
 }
 public void setHargaJual(Long hargaJual) {
 this.hargaJual = hargaJual;
 }
 public Long getHargaJual() {
 return hargaJual;
 }
 public void setProduk(Produk produk) {
 this.produk = produk;
    }
    public Produk getProduk() {
        return produk;
    }
}

