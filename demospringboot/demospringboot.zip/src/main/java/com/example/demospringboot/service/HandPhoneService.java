package com.example.demospringboot.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demospringboot.entity.HandPhone;
import com.example.demospringboot.repository.HandPhoneRepository;

@Service
public class HandPhoneService {
    @Autowired
    private HandPhoneRepository handphoneRepository;
    
    public List<HandPhone> getAllHandPhone() {
    
        return handphoneRepository.findAll();
    }
    
    public HandPhone addHandPhone(HandPhone obj){
        Long id = null;
        obj.setId(id);
        return handphoneRepository.save(obj);
    }

    public HandPhone getHandPhoneById(long id){
        return handphoneRepository.findById(id).orElse(null);
    }

    public HandPhone updateHandPhone (long id, HandPhone obj){
        obj.setId(id);
        return handphoneRepository.save(obj);
    }

    public void deleteHandPhone(long id){
        handphoneRepository.deleteById(id);
    }
}